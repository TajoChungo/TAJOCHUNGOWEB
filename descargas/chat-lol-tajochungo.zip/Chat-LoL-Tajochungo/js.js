const chat = document.getElementById('chat');
let fields = {};
let champs = {};
const knownSubs = new Set();
const recentEvents = new Map();

const CHAMPS = [
  "Aatrox","Ahri","Akali","Akshan","Alistar","Ambessa","Amumu","Anivia","Annie","Aphelios",
  "Ashe","Aurelion Sol","Aurora","Azir","Bardo","Bel'Veth","Blitzcrank","Brand","Braum","Briar",
  "Caitlyn","Camille","Cassiopeia","Cho'Gath","Corki","Darius","Diana","Dr. Mundo","Draven","Ekko",
  "Elise","Evelynn","Ezreal","Fiddlesticks","Fiora","Fizz","Galio","Gangplank","Garen","Gnar",
  "Gragas","Graves","Gwen","Hecarim","Heimerdinger","Hwei","Illaoi","Irelia","Ivern","Janna",
  "Jarvan IV","Jax","Jayce","Jhin","Jinx","K'Sante","Kai'Sa","Kalista","Karma","Karthus",
  "Kassadin","Katarina","Kayle","Kayn","Kennen","Kha'Zix","Kindred","Kled","Kog'Maw","LeBlanc",
  "Lee Sin","Leona","Lillia","Lissandra","Locke","Lucian","Lulu","Lux","Malphite","Malzahar",
  "Maokai","Master Yi","Mel","Milio","Miss Fortune","Mordekaiser","Morgana","Naafiri","Nami","Nasus",
  "Nautilus","Neeko","Nidalee","Nilah","Nocturne","Nunu & Willump","Olaf","Orianna","Ornn","Pantheon",
  "Poppy","Pyke","Qiyana","Quinn","Rakan","Rammus","Rek'Sai","Rell","Renata Glasc","Renekton",
  "Rengar","Riven","Rumble","Ryze","Samira","Sejuani","Senna","Seraphine","Sett","Shaco",
  "Shen","Shyvana","Singed","Sion","Sivir","Skarner","Smolder","Sona","Soraka","Swain",
  "Sylas","Syndra","Tahm Kench","Taliyah","Talon","Taric","Teemo","Thresh","Tristana","Trundle",
  "Tryndamere","Twisted Fate","Twitch","Udyr","Urgot","Varus","Vayne","Veigar","Vel'Koz","Vex",
  "Vi","Viego","Viktor","Vladimir","Volibear","Warwick","Wukong","Xayah","Xerath","Xin Zhao",
  "Yasuo","Yone","Yorick","Yunara","Yuumi","Zaahen","Zac","Zed","Zeri","Ziggs",
  "Zilean","Zoe","Zyra"
];

const ALIASES = {
  nunu: "Nunu & Willump", jarvan: "Jarvan IV", mundo: "Dr. Mundo", renata: "Renata Glasc",
  tf: "Twisted Fate", mf: "Miss Fortune", yi: "Master Yi", asol: "Aurelion Sol",
  monkeyking: "Wukong", tahm: "Tahm Kench", xin: "Xin Zhao", lee: "Lee Sin",
  cho: "Cho'Gath", kog: "Kog'Maw", kha: "Kha'Zix", velkoz: "Vel'Koz", heimer: "Heimerdinger",
  fiddle: "Fiddlesticks", bard: "Bardo", gp: "Gangplank", blitz: "Blitzcrank", cass: "Cassiopeia", morde: "Mordekaiser"
};

// ID del chatroom de Kick. Se rellena desde el panel de ajustes (vacío = sin Kick).
const KICK_DEFAULT_ID = '';

function norm(s) {
  return String(s).toLowerCase().normalize('NFD')
    .replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
}

const CHAMP_MAP = {};
CHAMPS.forEach(c => { CHAMP_MAP[norm(c)] = c; });
Object.keys(ALIASES).forEach(k => { CHAMP_MAP[k] = ALIASES[k]; });

function esc(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function pad(n) { return String(n).padStart(2, '0'); }

function timeStr() {
  try {
    return new Date().toLocaleTimeString('es-ES', {
      timeZone: 'Europe/Madrid', hour: '2-digit', minute: '2-digit', hour12: false
    });
  } catch (e) {
    const d = new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
}

function isDuplicate(k) {
  const now = Date.now();
  const last = recentEvents.get(k);
  recentEvents.set(k, now);
  return last !== undefined && now - last < 3000;
}

function saveChamps() {
  try { SE_API.store.set('lolChamps', champs); } catch (e) {}
}

function kickTag(platform) {
  return platform === 'kick' && fields.kickTag !== false ? '<span class="kick-tag">K</span>' : '';
}

function nameHTML(displayName, isSub, badgesHTML) {
  const champ = champs[String(displayName).toLowerCase()];
  const label = esc(displayName) + (champ ? ' (' + esc(champ) + ')' : '');
  return '<span class="name ' + (isSub ? 'sub' : 'nosub') + '">' + (badgesHTML || '') + label + '</span>';
}

function addLine(innerHTML, msgId, userId, extraClass) {
  const div = document.createElement('div');
  div.className = 'msg' + (extraClass ? ' ' + extraClass : '');
  if (msgId) div.dataset.id = msgId;
  if (userId) div.dataset.user = userId;
  const time = fields.showTime === true ? '<span class="time">' + timeStr() + '</span> ' : '';
  div.innerHTML = time + innerHTML;
  chat.appendChild(div);

  const max = Number(fields.maxMessages) || 10;
  while (chat.children.length > max) chat.firstChild.remove();

  const hide = Number(fields.hideAfter) || 0;
  if (hide > 0) {
    setTimeout(() => {
      div.classList.add('fade');
      setTimeout(() => div.remove(), 700);
    }, hide * 1000);
  }
}

// Eventos al estilo LoL: "¡Nombre ha hecho algo!"
function eventLine(name, text, platform) {
  const isSub = knownSubs.has(String(name).toLowerCase());
  addLine(
    kickTag(platform) + '<span class="event">¡</span>' + nameHTML(String(name), isSub) +
    ' <span class="event">' + esc(text) + '!</span>'
  );
}

// Mensaje de chat común para Twitch y Kick
function chatMessage(o) {
  if (o.msgId && document.querySelector('[data-id="' + o.msgId + '"]')) return;

  const displayName = o.displayName || 'Anónimo';
  const key = String(displayName).toLowerCase();
  const msgText = String(o.msgText || '');

  if (o.isSub) knownSubs.add(key);

  if (msgText.startsWith('!')) {
    const body = msgText.slice(1).trim();
    const whole = norm(body);

    if (whole === 'quitarcampeon') {
      delete champs[key];
      saveChamps();
      return;
    }

    const champ = CHAMP_MAP[whole] || CHAMP_MAP[norm(body.split(/\s+/)[0])];
    if (champ) {
      champs[key] = champ;
      saveChamps();
      if (fields.announcePick !== false) {
        addLine(kickTag(o.platform) + nameHTML(displayName, o.isSub) +
          ' <span class="event">ha elegido a ' + esc(champ) + '.</span>');
      }
      return;
    }

    if (fields.ignoreCommands !== false) return;
  }

  addLine(
    kickTag(o.platform) + nameHTML(displayName, o.isSub, o.badgesHTML) +
    ': <span class="text">' + o.textHTML + '</span>',
    o.msgId, o.userId,
    (o.isVip && fields.vipPink !== false) ? 'vip' : ''
  );
}

// ================= KICK =================
let kickWs = null;
let kickPing = null;
let kickRetry = null;

function kickEmotes(html) {
  return html.replace(/\[emote:(\d+):([^\]]*)\]/g, (m, id, name) =>
    '<img src="https://files.kick.com/emotes/' + id + '/fullsize" alt="' + name + '">');
}

function connectKick() {
  const id = String(fields.kickChatroomId || KICK_DEFAULT_ID).trim();
  if (!/^\d+$/.test(id)) return;

  clearTimeout(kickRetry);
  try {
    kickWs = new WebSocket('wss://ws-us2.pusher.com/app/32cbd69e4b950bf97679?protocol=7&client=js&version=8.4.0-rc2&flash=false');
  } catch (e) {
    kickRetry = setTimeout(connectKick, 10000);
    return;
  }

  kickWs.onopen = () => {
    ['chatrooms.' + id + '.v2', 'chatrooms.' + id].forEach(ch => {
      kickWs.send(JSON.stringify({ event: 'pusher:subscribe', data: { auth: '', channel: ch } }));
    });
    clearInterval(kickPing);
    kickPing = setInterval(() => {
      try { kickWs.send(JSON.stringify({ event: 'pusher:ping', data: {} })); } catch (e) {}
    }, 60000);
  };

  kickWs.onmessage = e => {
    try { handleKick(JSON.parse(e.data)); } catch (err) { console.log('Kick:', err); }
  };

  kickWs.onclose = () => {
    clearInterval(kickPing);
    kickRetry = setTimeout(connectKick, 5000);
  };

  kickWs.onerror = () => {
    try { kickWs.close(); } catch (e) {}
  };
}

function handleKick(msg) {
  const ev = msg.event;
  if (ev === 'pusher:ping') {
    kickWs.send(JSON.stringify({ event: 'pusher:pong', data: {} }));
    return;
  }
  if (!ev || ev.indexOf('App\\Events\\') !== 0) return;

  const data = typeof msg.data === 'string' ? JSON.parse(msg.data) : msg.data;
  if (!data) return;

  if (ev === 'App\\Events\\ChatMessageEvent' || ev === 'App\\Events\\ChatMessageSentEvent') {
    let id, content, sender;
    if (data.sender) {
      id = data.id; content = data.content; sender = data.sender;
    } else if (data.message && data.user) {
      id = data.message.id; content = data.message.message; sender = data.user;
    } else {
      return;
    }

    const username = sender.username || sender.slug || 'Anónimo';
    const badges = (sender.identity && sender.identity.badges) || [];
    const types = badges.map(b => b.type);
    const isBroadcaster = types.includes('broadcaster');
    const isSub = types.includes('subscriber') || types.includes('founder') ||
      (isBroadcaster && fields.broadcasterBlue !== false);

    chatMessage({
      platform: 'kick',
      displayName: username,
      msgText: content,
      textHTML: kickEmotes(esc(content || '')),
      isSub: isSub,
      isVip: types.includes('vip'),
      badgesHTML: '',
      msgId: 'kick-' + id,
      userId: 'kick:' + String(username).toLowerCase()
    });
    return;
  }

  if (ev === 'App\\Events\\MessageDeletedEvent' && data.message) {
    document.querySelectorAll('[data-id="kick-' + data.message.id + '"]').forEach(e => e.remove());
    return;
  }
  if (ev === 'App\\Events\\UserBannedEvent' && data.user) {
    const u = 'kick:' + String(data.user.username || '').toLowerCase();
    document.querySelectorAll('[data-user="' + u + '"]').forEach(e => e.remove());
    return;
  }

  if (fields.kickEvents === false) return;

  if (ev === 'App\\Events\\SubscriptionEvent' && data.username) {
    if (isDuplicate('kick-sub|' + data.username + '|' + data.months)) return;
    knownSubs.add(String(data.username).toLowerCase());
    eventLine(data.username, data.months > 1 ? 'se ha suscrito (' + data.months + ' meses)' : 'se ha suscrito', 'kick');
    return;
  }
  if (ev === 'App\\Events\\GiftedSubscriptionsEvent') {
    const list = data.gifted_usernames || [];
    const gifter = data.gifter_username || 'Anónimo';
    if (isDuplicate('kick-gift|' + gifter + '|' + list.join(','))) return;
    list.forEach(u => knownSubs.add(String(u).toLowerCase()));
    if (list.length === 1) eventLine(gifter, 'ha regalado una sub a ' + list[0], 'kick');
    else eventLine(gifter, 'ha regalado ' + list.length + ' subs a la comunidad', 'kick');
    return;
  }
}

// ================= STREAMELEMENTS / TWITCH =================
window.addEventListener('onWidgetLoad', obj => {
  try {
    fields = (obj && obj.detail && obj.detail.fieldData) || {};
    const r = document.documentElement.style;
    if (fields.fontSize) r.setProperty('--size', fields.fontSize + 'px');
    if (fields.fontFamily) r.setProperty('--font', "'" + fields.fontFamily + "'");
    if (fields.fontWeight) r.setProperty('--weight', fields.fontWeight);
    if (fields.textColor) r.setProperty('--text', fields.textColor);
    if (fields.timeColor) r.setProperty('--time', fields.timeColor);
    if (fields.subColor) r.setProperty('--sub', fields.subColor);
    if (fields.nonSubColor) r.setProperty('--nosub', fields.nonSubColor);
    if (fields.eventColor) r.setProperty('--event', fields.eventColor);
    if (fields.vipColor) r.setProperty('--vip', fields.vipColor);
    if (fields.bgOpacity !== undefined && fields.bgOpacity !== '') r.setProperty('--bg', fields.bgOpacity);
  } catch (e) {}

  try {
    SE_API.store.get('lolChamps').then(v => {
      if (v && typeof v === 'object') {
        champs = v;
        Object.keys(champs).forEach(k => { if (champs[k] === 'Bard') champs[k] = 'Bardo'; });
      }
    }).catch(() => {});
  } catch (e) {}

  connectKick();
});

window.addEventListener('onEventReceived', obj => {
  try {
    const listener = obj.detail.listener;
    const ev = obj.detail.event;

    if (listener === 'delete-message') {
      document.querySelectorAll('[data-id="' + ev.msgId + '"]').forEach(e => e.remove());
      return;
    }
    if (listener === 'delete-messages') {
      document.querySelectorAll('[data-user="' + ev.userId + '"]').forEach(e => e.remove());
      return;
    }

    const EVENTS = ['follower-latest', 'subscriber-latest', 'cheer-latest', 'raid-latest', 'tip-latest'];
    if (EVENTS.includes(listener)) {
      if (isDuplicate([listener, ev.name, ev.amount, ev.sender, ev.message].join('|'))) return;

      if (listener === 'follower-latest') {
        eventLine(ev.name, 'ha empezado a seguir el canal');
      }
      else if (listener === 'subscriber-latest') {
        if (ev.isCommunityGift) return;
        const sameName = ev.sender && String(ev.sender).toLowerCase() === String(ev.name).toLowerCase();
        if (ev.bulkGifted) {
          eventLine(ev.sender || ev.name, 'ha regalado ' + ev.amount + ' subs a la comunidad');
        } else if (ev.gifted && ev.sender && !sameName) {
          knownSubs.add(String(ev.name).toLowerCase());
          eventLine(ev.sender, 'ha regalado una sub a ' + ev.name);
        } else {
          knownSubs.add(String(ev.name).toLowerCase());
          eventLine(ev.name, ev.amount > 1 ? 'se ha suscrito (' + ev.amount + ' meses)' : 'se ha suscrito');
        }
      }
      else if (listener === 'cheer-latest') {
        eventLine(ev.name, 'ha lanzado ' + ev.amount + ' bits');
      }
      else if (listener === 'raid-latest') {
        eventLine(ev.name, 'ha hecho una raid con ' + ev.amount + ' espectadores');
      }
      else if (listener === 'tip-latest') {
        eventLine(ev.name, 'ha donado ' + ev.amount + '€');
      }
      return;
    }

    if (listener !== 'message') return;

    const d = ev.data;
    const badges = d.badges || [];
    const types = badges.map(b => b.type);
    const isBroadcaster = types.includes('broadcaster');
    const isSub = types.includes('subscriber') || types.includes('founder') ||
      (d.tags && d.tags.subscriber === '1') ||
      (isBroadcaster && fields.broadcasterBlue !== false);

    const subBadges = badges
      .filter(b => (b.type === 'subscriber' || b.type === 'founder') && b.url)
      .map(b => '<img class="badge" src="' + b.url + '">')
      .join('');

    chatMessage({
      platform: 'twitch',
      displayName: d.displayName || d.nick,
      msgText: d.text,
      textHTML: ev.renderedText || esc(d.text || ''),
      isSub: isSub,
      isVip: types.includes('vip') || (d.tags && d.tags.vip === '1'),
      badgesHTML: subBadges,
      msgId: d.msgId,
      userId: d.userId
    });
  } catch (e) {
    console.log('Error en el chat:', e);
  }
});
